import 'dart:ui';

class color{

  static const Color my_Primariycolor = Color(0xff252e39);

  static const Color secondcolor = Color(0xff03A9F4);

  // static const Color thirdcolor = Color(0xff2962FF);
  // static const Color thirdcolor = Color(0xff7F3DFF);
  // static const Color thirdcolor = Color(0xff161941);


  // static const Color thirdcolor = Color(0xff0039a3);
  // static const Color thirdcolor = Color(0xff173d39);
  // static const Color thirdcolor = Color(0xff04013a);
  // static const Color thirdcolor = Color(0xff103f6f);
  // static const Color thirdcolor = Color(0xff4b1473);
  // static const Color thirdcolor = Color(0xff0e3e24);
  // static const Color thirdcolor = Color(0xff609a9f);
  static const Color thirdcolor = Color(0xff294144);





  static const Color fourcolor = Color(0xffFFFFFF);
}